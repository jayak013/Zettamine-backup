package com.zettamine.game;

public class GameRunner {
	/*
	private Mario marioGame;
    
	public GameRunner(Mario marioGame) {
		super();
		this.marioGame = marioGame;
	}

	public void run() {
		System.out.println("Running Game: " + marioGame);
		
	}
	*/
	private SuperContra superGame;

	public GameRunner(SuperContra superGame) {
		super();
		this.superGame = superGame;
	}
	public void run() {
		System.out.println("Running Game: " + superGame);
		
	}	

}
