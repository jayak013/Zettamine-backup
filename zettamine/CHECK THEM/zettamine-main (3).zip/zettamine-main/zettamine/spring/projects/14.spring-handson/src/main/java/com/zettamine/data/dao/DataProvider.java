package com.zettamine.data.dao;

public interface DataProvider {
	int[] getData();
}
