package com.zettamine.spring.beans;

import org.springframework.stereotype.Service;

@Service
public class Service2 {

	@Override
	public String toString() {
		return "Service-2";
	}

}
