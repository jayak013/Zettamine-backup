package com.zettamine.spring.beans;

import org.springframework.stereotype.Service;

@Service
public class Service1 {

	@Override
	public String toString() {
		return "Service 1";
	}

}
