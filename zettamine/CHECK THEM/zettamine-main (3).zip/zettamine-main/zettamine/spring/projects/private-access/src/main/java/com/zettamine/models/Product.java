package com.zettamine.models;

public class Product {
	private String productName;

	@Override
	public String toString() {
		return "Product [productName=" + productName + "]";
	}	
}
