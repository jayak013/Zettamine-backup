package com.zettamine.spring.core.beans.services;

import org.springframework.stereotype.Service;

@Service
public class UserServices {

	public UserServices() {
		System.out.println("UserService :: Constructor");
	}

}
