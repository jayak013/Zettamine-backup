package com.zettamine.spring.core.beans.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {

	public UserController() {
		System.out.println("UserController :: Constructor");
	}

}
