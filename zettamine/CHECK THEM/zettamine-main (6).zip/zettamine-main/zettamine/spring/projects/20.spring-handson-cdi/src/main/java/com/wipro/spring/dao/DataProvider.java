package com.wipro.spring.dao;

public interface DataProvider {
	int[] getData();
}
