package com.zettamine.materialInspection.utils;

public enum State {
	
}
