package com.zettamine.materialInspection.service;

import java.util.List;

import com.zettamine.materialInspection.entities.MaterialInspLot;

public interface MaterialInspLotService {

	MaterialInspLot addLot(MaterialInspLot materialInspLot);
}
