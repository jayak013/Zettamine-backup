package com.zettamine.amc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmcModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
