package com.zettamine.amc.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zettamine.amc.entity.AppraisalCompany;

public interface AppraisalCompanyRepository extends JpaRepository<AppraisalCompany, Serializable>{

}
