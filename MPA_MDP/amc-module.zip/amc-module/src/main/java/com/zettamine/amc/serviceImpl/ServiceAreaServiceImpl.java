package com.zettamine.amc.serviceImpl;

import com.zettamine.amc.service.ServiceAreaService;

public class ServiceAreaServiceImpl implements ServiceAreaService {

}
