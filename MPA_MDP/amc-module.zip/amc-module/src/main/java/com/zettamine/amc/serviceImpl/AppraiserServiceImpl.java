package com.zettamine.amc.serviceImpl;

import com.zettamine.amc.service.AppraiserService;

public class AppraiserServiceImpl implements AppraiserService{

}
