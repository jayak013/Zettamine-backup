package com.zettamine.amc.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zettamine.amc.entity.ServiceArea;

public interface ServiceAreaRepository extends JpaRepository<ServiceArea, Serializable> {

}
