package com.zettamine.amc.serviceImpl;

import com.zettamine.amc.service.PropertyTypeService;

public class PropertyTypeServiceImp implements PropertyTypeService{

}
