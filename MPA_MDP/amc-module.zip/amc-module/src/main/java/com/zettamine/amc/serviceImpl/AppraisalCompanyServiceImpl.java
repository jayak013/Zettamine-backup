package com.zettamine.amc.serviceImpl;

import com.zettamine.amc.service.AppraisalCompanyService;

public class AppraisalCompanyServiceImpl implements AppraisalCompanyService {

}
