package com.zettamine.amc.exception;

public class GlobalExceptionHandler {

}
