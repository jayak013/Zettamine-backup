package com.zettamine.amc.service;

public interface AppraiserService {

}
