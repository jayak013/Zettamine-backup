package com.zettamine.amc.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zettamine.amc.entity.PropertyType;

public interface PropertyTypeRepository extends JpaRepository<PropertyType, Serializable> {

}
