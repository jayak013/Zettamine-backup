package com.zettamine.amc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmcModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmcModuleApplication.class, args);
	}

}
