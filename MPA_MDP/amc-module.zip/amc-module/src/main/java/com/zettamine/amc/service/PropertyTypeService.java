package com.zettamine.amc.service;

public interface PropertyTypeService {

}
