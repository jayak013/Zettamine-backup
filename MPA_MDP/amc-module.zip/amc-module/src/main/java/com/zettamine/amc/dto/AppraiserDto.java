package com.zettamine.amc.dto;

public class AppraiserDto {

}
