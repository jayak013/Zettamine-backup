package com.zettamine.iostreams.copy;

public interface CopierFactory {
	
	FolderCopier createFileCopier();
	
}
