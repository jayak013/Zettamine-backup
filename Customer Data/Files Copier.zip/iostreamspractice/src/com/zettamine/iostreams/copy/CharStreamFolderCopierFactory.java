package com.zettamine.iostreams.copy;

public class CharStreamFolderCopierFactory implements CopierFactory {

	@Override
	public FolderCopier createFileCopier() {
		return new CharStreamFolderCopier();
	}

}
