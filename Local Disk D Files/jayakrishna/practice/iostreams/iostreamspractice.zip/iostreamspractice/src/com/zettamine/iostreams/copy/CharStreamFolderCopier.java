package com.zettamine.iostreams.copy;

public class CharStreamFolderCopier implements FolderCopier {

	@Override
	public void replicate(String sourceFolder, String destinationFolder) {
		System.out.println("CharStreamFolderCopier");
	}

}
