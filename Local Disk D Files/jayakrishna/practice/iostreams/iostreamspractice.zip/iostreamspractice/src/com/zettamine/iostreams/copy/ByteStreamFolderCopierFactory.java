package com.zettamine.iostreams.copy;

public class ByteStreamFolderCopierFactory implements CopierFactory {

	@Override
	public FolderCopier createFileCopier() {
		return new ByteStreamFolderCopier();
	}

}
