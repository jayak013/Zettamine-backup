npm install

npx json-server data/db.json -p 444

npm start