package com.zettamine.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapperDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
