import './App.css';
import Contents from './components/Contents';
import Header from './components/Header';

function App() {
  return (
    <div>
      <Header/>
      <Contents/>
    </div>
  );
}

export default App;
