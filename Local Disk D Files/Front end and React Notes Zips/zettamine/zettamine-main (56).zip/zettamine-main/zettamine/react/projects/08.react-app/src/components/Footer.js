import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <footer>
        <p>TaskMate by ZettaMine &copy; 2024-2025</p>
    </footer>
  )
}

export default Footer

