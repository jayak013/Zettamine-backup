import {Employee} from './Person/Employee/employee.js'
let emp = new Employee('Sunil', 'Joseph',25000)
emp.getDetails()