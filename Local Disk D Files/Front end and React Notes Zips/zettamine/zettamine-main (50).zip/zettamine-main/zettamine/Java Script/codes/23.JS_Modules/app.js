import {greetings} from './script.js'
greetings('Aditya');