package com.zettamine.boot.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zettamine.boot.dto.UserDto;
import com.zettamine.boot.entity.User;
import com.zettamine.boot.mapper.UserMappers;

@RestController
public class UserController {
	@PostMapping("/api/create")
	public ResponseEntity<?> createUser(@RequestBody UserDto userDto) {
		User userEntity = UserMappers.MAPPER.mapToUser(userDto);
		System.out.println(userEntity);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
