package com.zettamine.boot.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.zettamine.boot.dto.UserDto;
import com.zettamine.boot.entity.User;

@Mapper
public interface UserMappers {

    UserMappers MAPPER = Mappers.getMapper(UserMappers.class);

    @Mapping(source = "email", target = "emailAddress")
    UserDto mapToUserDto(User user);

    @Mapping(source = "emailAddress", target = "email")
    User mapToUser(UserDto userDto);
}
