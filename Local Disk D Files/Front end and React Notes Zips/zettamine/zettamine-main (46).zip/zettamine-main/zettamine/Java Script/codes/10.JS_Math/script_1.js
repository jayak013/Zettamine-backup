console.log(Math.E)
console.log(`PI = ${Math.PI}`)

console.log(`sin(0) = ${Math.sin(0)}`)
console.log(`cos(0) = ${Math.cos(0)}`)
console.log(`sqrt(25) = ${Math.sqrt(25)}`)

console.log(`max(10,20,34,5,12) = ${Math.max(10,20,34,5,12)}`)
console.log(`min(10,20,34,5,12) = ${Math.min(10,20,34,5,12)}`)

console.log(`floor(10.9) = ${Math.floor(10.9)}`)
console.log(`ceil(10.9) = ${Math.ceil(10.9)}`)

console.log(`round(10.5456) = ${Math.round(10.5456)}`)
let otp = Math.random();
console.log(otp)
otp = otp*10000
console.log(`OTP = ${Math.round(otp)}`)
console.log(`OTP = ${Math.floor(otp)}`)

console.log(`abs(-10) = ${Math.abs(-10)}`)

console.log(`pow(5,3) = ${Math.pow(5,3)}`)
console.log(`pow(5,3) = ${5 ** 3}`) //ES6