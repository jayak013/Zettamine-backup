import React, {Fragment, Component} from 'react'
class EnvironmentSetup extends Component{
    render(){
        return (
            <Fragment>
                <div className="card">
                    <div className="card-body">
                        <h2>02. Environment Setp</h2>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Atque obcaecati natus autem, dicta deleniti quod possimus quidem sit consequatur voluptates veritatis doloribus adipisci beatae qui laudantium eligendi eveniet amet itaque!</p>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default EnvironmentSetup;