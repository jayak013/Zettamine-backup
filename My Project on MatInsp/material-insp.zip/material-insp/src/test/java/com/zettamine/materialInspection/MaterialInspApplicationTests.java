package com.zettamine.materialInspection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialInspApplicationTests {

	@Test
	void contextLoads() {
	}

}
