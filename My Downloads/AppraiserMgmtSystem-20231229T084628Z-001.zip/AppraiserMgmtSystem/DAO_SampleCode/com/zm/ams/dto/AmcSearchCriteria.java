package com.zm.ams.dto;

public class AmcSearchCriteria implements SearchCriteria {
	private String amcName;
	private String state;
	private String city;
	
	
}
